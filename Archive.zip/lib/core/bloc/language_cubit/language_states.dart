abstract class LanguageState {}

class InitLanguageState extends LanguageState {}

class SelectLanguage extends LanguageState {}

class EnglishLanguageState extends LanguageState {}

class ArabicLanguageState extends LanguageState {}