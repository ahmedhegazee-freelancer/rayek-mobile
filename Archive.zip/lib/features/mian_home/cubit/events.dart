abstract class NavigationEvents {}

class HomePageClickedEvent extends NavigationEvents {}

class ExpertsPageClickedEvent extends NavigationEvents {}

class ChatPageClickedEvent extends NavigationEvents {}

class CallPageClickedEvent extends NavigationEvents {}

class SettingsPageClickedEvent extends NavigationEvents {}