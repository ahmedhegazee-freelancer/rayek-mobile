
abstract class NavigationStates {}


class HomePageState extends NavigationStates {}

class ExpertsPageState extends NavigationStates {}

class ChatPageState extends NavigationStates {}

class CallPageState extends NavigationStates {}

class SettingsPageState extends NavigationStates {}