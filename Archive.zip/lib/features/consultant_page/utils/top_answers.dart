
// container have top answers that contain column of question and answer


